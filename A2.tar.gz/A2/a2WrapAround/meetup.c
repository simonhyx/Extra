/*Required Headers*/

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <semaphore.h>
#include "meetup.h"
#include "resource.h"

/*
 * Declarations for barrier shared variables -- plus concurrency-control
 * variables -- must START here.
 */
#define arSize 2

pthread_mutex_t key;
pthread_cond_t m;

int SizeofHips;
int generation;
int count;
int mode;
int readBlock;





resource_t ar[arSize];
int cap;
int offset;






void *erealloc(void *ptr ,size_t n){
	void *p; 
	p = realloc(ptr,n);
	if (p==NULL){
		fprintf(stderr, "realloc failed, out of memory");
		exit(1);
	}
	return p;
}


void *emalloc(size_t n){
	void *p; 
	p = malloc(n);
	if (p==NULL){
		fprintf(stderr, "malloc failed, out of memory");
		exit(1);
	}
	return p;
}










//recource_t * resource;

void initialize_meetup(int n, int mf) {
    char label[100];
    int i;

    if (n < 1) {
        fprintf(stderr, "Who are you kidding?\n");
        fprintf(stderr, "A meetup size of %d??\n", n);
        exit(1);
    }

	pthread_mutex_init(&key, NULL);
	int ret = pthread_cond_init(&m,NULL);
	SizeofHips = n;
	readBlock = 0;

	if (mf == 0){
		mode =0;
		// meet first
	}else if(mf==1){
		mode = 1;
	}else {
		fprintf(stderr, "meet option error");
		exit(1);
	}


}


void join_meetup(char *value, int len) {

	pthread_mutex_lock(&key);
	count = count +1;
printf("\nvalue = %s, count = %d \n", value, count );

	if (count < SizeofHips){
		int mygen = generation;


                resource_t* word = ar;
                word = word + mygen%arSize ;





  



                if (mode == 1 && count == 1){ // if in meet first mode store the code word for the first person

			if(mygen >= arSize){ // check if the current resource is dirty (there are still reads to be done on its value)
				readBlock++; // This problem only exist in meet first mode, has to prevent broadcast when resource is dirty.
				pthread_mutex_unlock(&key);
				for (;;){
					//printf("enter spin1");
					pthread_mutex_lock(&key);
					if(word->num_reads == SizeofHips){
						break;
					}else{
						pthread_mutex_unlock(&key);
					}
					//spin
				}// no longer dirty, unblock
				readBlock--;
			}

                        write_resource(word, value, strlen(value)+1);
                }


		while(mygen == generation%arSize){
printf("line 138 value = %s", value);
			pthread_cond_wait(&m, &key);
//break;
printf("line 139 value = %s", value);
		}

		char * temp = word-> value;
		//printf("temp = %s\n value = %s\n", temp,value);
printf("line 141 value = %s", value);
		pthread_mutex_unlock(&key);
		read_resource(word, value,strlen(temp)+1);

		
	}else{


		pthread_mutex_unlock(&key);
		for (;;){ // readBlock acts like a semaphore
			pthread_mutex_lock(&key);
			// spin
			if(readBlock==0){
				break;
			}else{
				pthread_mutex_unlock(&key);
			}
			
		}


		resource_t* word= ar;
		word = word + generation%arSize;




		if (mode == 0){ // if in meet last mode store the code word for the first person
			//printf("\nLine 184 writing value = %s\n",value);
			if(generation >= arSize && word->num_reads !=SizeofHips){ // check if the current resource is dirty (there are still reads to be done on its value)
				
				pthread_mutex_unlock(&key);
				for (;;){
					//printf("enter spin2");
					pthread_mutex_lock(&key);
					if(word->num_reads == SizeofHips){
						break;
					}else{
						pthread_mutex_unlock(&key);
					}
					//spin
				}
			}


			write_resource(word, value, strlen(value)+1);
			
		}
		char * temp = word-> value;
		//read_resource(word, value,strlen(temp)+1);
		count = 0;
		generation++;

		pthread_cond_broadcast(&m);
		pthread_mutex_unlock(&key);
		read_resource(word, value,strlen(temp)+1);
		
	}




}










