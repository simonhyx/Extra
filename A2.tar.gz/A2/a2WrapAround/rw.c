/*Required Headers*/

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <semaphore.h>
#include "rw.h"
#include "resource.h"

/*
 * Declarations for reader-writer shared variables -- plus concurrency-control
 * variables -- must START here.
 */

sem_t keys;
sem_t blockreaders;
int reader;
int writerRequests;

static resource_t data;

void initialize_readers_writer() {
    /*
     * Initialize the shared structures, including those used for
     * synchronization.
     */
	sem_init(&keys,0,1);
	sem_init(&blockreaders,0,1);
	reader = 0;
	writerRequests;
}


void rw_read(char *value, int len) {
    printf("NOTHING IMPLEMENTED YET FOR rw_read\n");
	sem_wait(&blockreaders); // if to many writer requests, block readers from entering. 
	sem_post(&blockreaders);

	sem_wait(&keys);
	reader++;
	sem_post(&keys);	
	// issue read
	read_resource(&data,value,len);
	sem_wait(&keys);
	reader--;
	sem_post(&keys);
	
	
	
	
}


void rw_write(char *value, int len) {
    printf("NOTHING IMPLEMENTED YET FOR rw_write\n");
	

	for(;;){
		sem_wait(&keys);
		writerRequests++;
		if(reader == 0){
			break;
		}else if(writerRequests>5){
			//block readers
			sem_wait(&blockreaders);
			sem_post(&keys);
			while(reader !=0){
				sem_wait(&keys);
				if(reader == 0){
					break;
				}else{
					sem_post(&keys);
				} // eventually it would break because we blocked any readers from entering
				// unless a reader decides to read forever
			}
			writerRequests = 0;
			sem_post(&blockreaders); // now readers are zero, but we have mutext key, so unblock readers and perform writer.
			break; // now the readers has to be zero, and we've obtained the mutext key. 
		}else{
			sem_post(&keys);
		}
	}
	
	// now writer has key. no one can enter.
	// issue write
printf("reader = %d\n", reader);
	write_resource(&data,value,len);
	sem_post(&keys);
	
	
}
