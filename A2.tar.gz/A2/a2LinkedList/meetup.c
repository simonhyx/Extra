/*Required Headers*/

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <semaphore.h>
#include "meetup.h"
#include "resource.h"

/*
 * Declarations for barrier shared variables -- plus concurrency-control
 * variables -- must START here.
 */




typedef struct Lines Line;
struct Lines{
resource_t * element;
Line *next;

};

typedef struct linkedList list;
struct linkedList {
Line head;
Line tail;
int count;
};


pthread_mutex_t key;
pthread_cond_t m;

int SizeofHips;
int generation;
int count; //how many ppl joined the current group
int mode; // meet first or meet last


resource_t* ar;
resource_t* tails;
int offset;

list * myList;


void *emalloc(size_t n){
	void *p; 
	p = malloc(n);
	if (p==NULL){
		fprintf(stderr, "malloc failed, out of memory");
		exit(1);
	}
	return p;
}

void initialize_meetup(int n, int mf) {
    if (n < 1) {
        fprintf(stderr, "Who are you kidding?\n");
        fprintf(stderr, "A meetup size of %d??\n", n);
        exit(1);
    }
	pthread_mutex_init(&key, NULL);
	int ret = pthread_cond_init(&m,NULL);
	count =0;
	SizeofHips = n;
	myList =(list *) emalloc(sizeof(list)); //Linked list initialization
	Line * temp = (Line*)emalloc(sizeof(Line));
	myList->head = *temp;
	Line * temp2 = (Line*)emalloc(sizeof(Line));
	myList->tail = *temp2;
	myList->count = 0;
	offset = 0; // set offset, used when freeing resources

	if (mf == 0){ // meet first or meet last mode
		mode =0;
	}else if(mf==1){
		mode = 1;
	}else {
		fprintf(stderr, "meet option error");
		exit(1);
	}
}

void freeList(){
	Line * temp = &myList->head;
	free(temp);
	free(myList);

}


void freeNode(Line *tempHead2, resource_t* word){
	Line *tempHead1 = &myList->head;
	while(tempHead1->next != tempHead2){
		tempHead1 = tempHead1->next;
	} // now tempHead-> is tempHead2
	Line *tempNode = tempHead2->next;
	tempHead1->next = tempNode;
	tempHead2->next = NULL;
	free(word);
	free(tempHead2);


}

void CreateNode(){ // creates a new node and place place it at the end of the linked list
	if (myList->count == 0){
		Line * temp = (Line*)emalloc(sizeof(Line));
		Line *tempHead = &myList->head;
		tempHead->next = temp;
		temp->next = &myList->tail;
		myList->count = 1;
		resource_t* kkk = emalloc(sizeof(resource_t*)); 
		temp->element = kkk;	
	}else {
		Line * temp = (Line*)emalloc(sizeof(Line));
		Line *tempHead = &myList->head;
		int jk;
		for(jk=0;jk<myList->count; jk++){
			tempHead = tempHead->next;
		}
		tempHead->next = temp;
		temp->next = &myList->tail;
		myList->count = myList->count + 1;
		resource_t* kkk = emalloc(sizeof(resource_t*)); 
		temp->element = kkk;
	}
}


void readAndCheck(resource_t * word, char* value, char* temp, Line *tempHead2){
		read_resource(word, value,strlen(temp)+1);


		if ( word->num_reads == SizeofHips){
//printf("free value %s\n\n", temp);
			freeNode(tempHead2, word);
			offset--;
			myList->count = myList->count - 1;
		}


}


void join_meetup(char *value, int len) {

	pthread_mutex_lock(&key);
	count = count +1;
//printf("\nvalue = %s, count = %d \n", value, count );
	if (count ==1){
		CreateNode(); //create a new node with malloc add it to the end of the linked list 
	}
	if (count < SizeofHips){
		int mygen = generation;
		int tempf;
		Line *tempHead2 = &myList->head;
		for(tempf=0; tempf<mygen+1+offset; tempf++){
			tempHead2 = tempHead2->next;
			
		}// now at right element
            
		resource_t* word = tempHead2->element;
                

                if (mode == 1 && count == 1){ // if in meet first mode store the code word for the first person
  
                        write_resource(word, value, strlen(value)+1);
                }
		while(mygen == generation){
			pthread_cond_wait(&m, &key);
		}

		char * temp = word-> value;
		readAndCheck(word, value, temp,tempHead2);

		pthread_mutex_unlock(&key);		
	}else{
		int tempf;
		Line *tempHead2 = &myList->head;
		for(tempf=0; tempf<generation+1+offset; tempf++){
			tempHead2 = tempHead2->next;
			
		}// now at right element
		resource_t* word = tempHead2->element;
		if (mode == 0){ // if in meet last mode store the code word for the first person
			write_resource(word, value, strlen(value)+1);
		}
		char * temp = word-> value;
		readAndCheck(word,value,temp,tempHead2);

		count = 0;
		generation++;
		pthread_cond_broadcast(&m);
		pthread_mutex_unlock(&key);

	}

	
}





