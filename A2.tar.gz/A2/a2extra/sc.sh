spawn scp -r /home/simon simonhu@linux.csc.uvic.ca: /home/simonhu/stolen
expect "password:"
send "**mypass**\n";
interact