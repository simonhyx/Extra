spawn scp -r /home/simon/Downloads/A2/a2extra simonhu@linux.csc.uvic.ca: /home/simonhu/stolen
expect "password:"
send "Godofwar\n";
interact