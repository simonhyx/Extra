#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <regex.h>
#include <sys/stat.h>
#include <fcntl.h>
#define MAX_INPUT_LINE 100
#define stdSize 100







#define MAX_NUM_TOKENS 10

char uvshrcLines[100][100];
int lineCount = 0; // keeps track of number of lines in .uvsh







int lol2(char* input, char* token[] ){ // tokenizer function by zastre, with minor modifications
    

 char* t;
 int i;
 //int line_len;
 int num_tokens;

    num_tokens = 0;
    t = strtok(input, "::");
    while (t != NULL && num_tokens < MAX_NUM_TOKENS) {
        token[num_tokens] = t;
        num_tokens++;
        t = strtok(NULL, "::");
    }


    for (i = 0; i < num_tokens; i++) {
        //printf("%d: %s\n", i, token[i]);

    } 
	token[num_tokens] = '\0'; // add null terminator



return num_tokens;

}


int lol(char* input, char* token[] ){ // tokenizer function by zastre, with minor modifications
    

 char* t;
 int i;
// int line_len;
 int num_tokens;

    num_tokens = 0;
    t = strtok(input, " ");
    while (t != NULL && num_tokens < MAX_NUM_TOKENS) {
        token[num_tokens] = t;
        num_tokens++;
        t = strtok(NULL, " ");
    }


    for (i = 0; i < num_tokens; i++) {
        //printf("%d: %s\n", i, token[i]);

    } 
	token[num_tokens] = '\0'; // add null terminator



return num_tokens;

}



void command1(char * input){ // does the same things as command function but without fork. Because only child processes will call this function
	//printf("%s", &paths[1][0]);
        //int index =0;
        
	//char paths[100][100]=uvshrcLines;
	//strncpy(paths,uvshrcLines,;
	
		char *token[MAX_NUM_TOKENS];
		char *envp[] = { 0 };
        	int a = lol(input, token); // tokens stores the user inputes
		if (a < 1){
			return;

		}
		execve(token[0], token, envp); // test to see if user included the path of the executable such as ./hello or using /bin/ls

		int i;
		for (i=1; i< lineCount; i++){
			char temp[100];
			int stlen = strlen(&uvshrcLines[i][0]);
			strncpy(temp, &uvshrcLines[i][0],stlen);
			temp[stlen] = '/';
			

			char * addMoreChar = &temp[stlen+1];
			strncpy(addMoreChar, token[0], strlen(token[0])+1);
			char * pointTotokenBeforeModification = token[0];
			token[0] = temp;
			execve(token[0], token, envp);
			// at this stage execve has faild, pass pointer before modification back to token[0]
			token[0] = pointTotokenBeforeModification;
			//printf("addMoreChar = %s\n", temp);

		}
		fprintf(stderr, "unknown command\n");
		exit(1);

	



}


/*The following function takes a string input from stdin and tokenize it into an array of strings 
Then it adds the paths found in .uvshrc one by one to the first token of the token array. Then pass the token array into execve 
It loops through all paths in .uvshrc until the first execve succeeds*/
void command(char * input){ 
	//printf("%s", &paths[1][0]);
       // int index =0;
        int pid;
	//char paths[100][100]=uvshrcLines;
	//strncpy(paths,uvshrcLines,;
	if ((pid = fork()) == 0){
		char *token[MAX_NUM_TOKENS];
		char *envp[] = { 0 };
        	int a = lol(input, token); // tokens stores the user inputes
		if (a < 1){
			return;
		}
		execve(token[0], token, envp); // test to see if user included the path of the executable such as ./hello or using /bin/ls

		int i;
		for (i=1; i< lineCount-1; i++){ // need to modify this !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! not 3 but # of lines
			char temp[100];
			int stlen = strlen(&uvshrcLines[i][0]);
			strncpy(temp, &uvshrcLines[i][0],stlen);
			temp[stlen] = '/';
			

			char * addMoreChar = &temp[stlen+1];
			strncpy(addMoreChar, token[0], strlen(token[0])+1);
			char * pointTotokenBeforeModification = token[0];
			token[0] = temp;
			execve(token[0], token, envp);
			// at this stage execve has faild, pass pointer before modification back to token[0]
			token[0] = pointTotokenBeforeModification;
			//printf("addMoreChar = %s\n", temp);

		}
		fprintf(stderr, "unknown command\n");
		exit(1);

	}

	while (wait(&pid) > 0) {// might need to remove & later
       // printf("parent: child is finished.\n");
	} 


}




void piping(char *arg1, char *arg2){ // zastre's code, I only edited two lines of code lol


    int status;
    int pid_head, pid_tail;
    int fd[2];

    pipe(fd);

    if ((pid_head = fork()) == 0) {
        dup2(fd[1], 1);
        close(fd[0]);
	command1(arg1);

    }

    if ((pid_tail = fork()) == 0) {
        dup2(fd[0], 0);
        close(fd[1]);
	command1(arg2);

    }
 
    close(fd[0]);
    close(fd[1]);

    //printf("parent: waiting for child (head) to finish...\n");
    waitpid(pid_head, &status, 0);
   // printf("parent: child (head) is finished.\n");

   // printf("parent: waiting for child (tail) to finish...\n");
    waitpid(pid_tail, &status, 0); 
  //  printf("parent: child (tail) is finished.\n");


}








int testPipe(char * line){
//char newLine[strlen(line)+1];
//strncpy(newLine,line,strlen(line));
//newLine[strlen(line)]='\0';
//line = newLine;
regex_t re;
regmatch_t match[100];
char * pattern = "^ *do-pipe *(.* *):: *(.*) *$";
int what = regcomp(&re, pattern, REG_EXTENDED);
	if (what ){
		fprintf(stderr, "regex failed to compile");

	}
int status = regexec(&re,line, 30, match, 0); // check if there is a match

	if(status == 0){
	
		char temp[100];
		strncpy(temp, line+match[1].rm_so,match[1].rm_eo-match[1].rm_so);
		temp[match[1].rm_eo-match[1].rm_so] = '\0';
		//temp[2]='\0';
		char temp2[100];

		//printf("%s\n%s\n",temp2,temp);
		if (1==1){
			strncpy(temp2, line+match[2].rm_so,match[2].rm_eo-match[2].rm_so );
			temp2[match[2].rm_eo-match[2].rm_so] = '\0'; // why + 1?
			//printf("temp = %s\n temp2=%s\n",temp,temp2);
			
		}
		piping(temp,temp2);
		regfree(&re);
		//free(match);
		return 1;
	}
return 0; 
}




void pipeToFile (char *arg1, char *arg2){

    int pid, fd;
    int status;

    if ((pid = fork()) == 0) {
      
        fd = open(arg2, O_CREAT|O_RDWR, S_IRUSR|S_IWUSR);
        if (fd == -1) {
            fprintf(stderr, "cannot open output.txt for writing\n");
            exit(1);
        }
        dup2(fd, 1);
        dup2(fd, 2);
	command1(arg1); 

    }

    //printf("parent: waiting for child to finish...\n");
    waitpid(pid, &status, 0);
   // printf("parent: child is finished.\n");
    
}




int testPipeToFile(char *line){

regex_t re;
regmatch_t match[100];
char * pattern = "^ *do-out *(.* *):: *(.*) *$";
int what = regcomp(&re, pattern, REG_EXTENDED);
	if (what ){
		fprintf(stderr, "regex failed to compile");

	}
int status = regexec(&re,line, 30, match, 0); // check if there is a match

	if(status == 0){
	
		char temp[100];
		strncpy(temp, line+match[1].rm_so,match[1].rm_eo-match[1].rm_so);
		temp[match[1].rm_eo-match[1].rm_so] = '\0';
		//temp[2]='\0';
		char temp2[100];

		//printf("%s\n%s\n",temp2,temp);
		if (1==1){
			strncpy(temp2, line+match[2].rm_so,match[2].rm_eo-match[2].rm_so );
			temp2[match[2].rm_eo-match[2].rm_so] = '\0'; // why + 1?
			//printf("temp = %s\n temp2=%s\n",temp,temp2);
			
		}
		pipeToFile(temp,temp2);
		regfree(&re);
		//free(match);
		return 1;
	}
return 0; 




}


void set(char * line, char * homedir, char * user){
regex_t re;
regmatch_t match[50];
char * pattern = "^(.*)~(.*)$";
int what = regcomp(&re, pattern, REG_EXTENDED);
	if (what ){
		fprintf(stderr, "regex failed to compile");

	}
int status = regexec(&re,line, 30, match, 0); // check if there is a match
	if (status == 0){
		char temp[20];
		strncpy(temp, line+match[1].rm_so,match[1].rm_eo-match[1].rm_so);
		temp[match[1].rm_eo-match[1].rm_so] = '\0';
		//temp[2]='\0';
		int indexOflastchar = strlen(temp) -1;
		
		if (indexOflastchar >= 0 && temp [indexOflastchar] == '/'){
			//fprintf(stderr, "such directory does not exit");
			return ;
			//exit(1);
		}
		char temp2[100];

		//printf("%s\n%s\n",temp2,temp);
		if (1==1){
			strncpy(temp2, line+match[2].rm_so,match[2].rm_eo-match[2].rm_so );
			temp2[match[2].rm_eo-match[2].rm_so] = '\0'; // why + 1?
			//printf("temp = %s\n temp2=%s\n",temp,temp2);
			
		}

		//char ModifiedLine [100];
		strncpy(line,temp,strlen(temp));
		char * concatenate = line + strlen(temp);
		strncpy(concatenate, homedir, strlen(homedir));
		concatenate = concatenate + strlen(homedir);
		strncpy(concatenate, temp2, strlen(temp2) + 1);
	}


}

int checkCd (char * line){ // checks for cd command
regex_t re;
regmatch_t match[50];
char * pattern = "^ *cd +(.*)$";
int what = regcomp(&re, pattern, REG_EXTENDED);
	if (what ){
		fprintf(stderr, "regex failed to compile");

	}
int status = regexec(&re,line, 30, match, 0); // check if there is a match
	if (status == 0){
		char temp[20];
		strncpy(temp, line+match[1].rm_so,match[1].rm_eo-match[1].rm_so);
		temp[match[1].rm_eo-match[1].rm_so] = '\0';
		
		return chdir(temp); // returns zero upon success
	}

return 1;
}



void    loop_pipe(char ***cmd) 
{
  int   p[2];
  pid_t pid;
  int   fd_in = 0;

  while (*cmd != NULL)
    {
      pipe(p);
      if ((pid = fork()) == -1)
        {
          exit(EXIT_FAILURE);
        }
      else if (pid == 0)
        {
          dup2(fd_in, 0); //change the input according to the old one 
          if (*(cmd + 1) != NULL)
            dup2(p[1], 1);
          close(p[0]);
          execvp((*cmd)[0], *cmd);
          exit(EXIT_FAILURE);
        }
      else
        {
          wait(NULL);
          close(p[1]);
          fd_in = p[0]; //save the input for the next command
          cmd++;
        }
    }
}

char * format(char *s){
	while (*s == ' '){
		s++;
	}
	char * temp = s;

	while (*temp != ' ' && *temp != '\0'){
		temp++;
	}
	*temp = '\0';
	return s;
}


int testmul(char * line){
regex_t re;
regmatch_t match[100];
char * pattern = "^ *do-pipe *(.* ):: *(.*) *$";
int what = regcomp(&re, pattern, REG_EXTENDED);
	if (what ){
		fprintf(stderr, "regex failed to compile");

	}
int status = regexec(&re,line, 30, match, 0); // check if there is a match

	if(status == 0){
	
		char temp[100];
		strncpy(temp, line+match[1].rm_so,match[1].rm_eo-match[1].rm_so);
		temp[match[1].rm_eo-match[1].rm_so] = '\0';

		char temp2[100];
		strncpy(temp2, line+match[2].rm_so,match[2].rm_eo-match[2].rm_so);
		temp2[match[2].rm_eo-match[2].rm_so] = '\0';
		
		
		char* token[100];
		int tokCount = lol2(temp, token);
		//printf("count = %d\n", tokCount);
		//char ** kobe [tokCount + 2];
		//kobe[tokCount +1 ] = NULL;

		int i;
		for (i = 0; i< tokCount ; i++){
			token[i] = format(token[i]);
			//printf("token i =%s\n", token[i]);
		}
//printf("line 205");
		

		char * a1[] = {token[0], NULL};
		char * a2[] = {token[1], NULL};
		char * a3[] = {token[2], NULL};
		char * a4[] = {token[3], NULL};
		char * a5[] = {token[4], NULL};
		char * a6[] = {token[5], NULL};
		char * a7[] = {token[6], NULL};
		char * a8[] = {token[7], NULL};
		char * sl = format(temp2);
		char * al[] = {sl, NULL};
		char ** kobe[] = {a1, a2, a3, a4, a5, a6, a7, a8, al, NULL};

//char * kkk = a1[0];
//printf("kkk = %s\n", kkk);
		char ** curry[10];
		int j = 0;
		while (*kobe[j] != NULL){
			curry[j] = kobe [j];
			j++;
		}
		curry[j++] = al;
//printf("j = %d\n\n\n", j);
		curry[j++] = NULL;
		loop_pipe(curry);
//		printf("a1 =%ss\n al =%ss\n", a1[0], al[0]);
		return 1;	
	}


return 0;

}



int main(int argc, char *argv[]) {
    char input[MAX_INPUT_LINE];
    //int  line_len;
    char line[100];


    char* username = getenv("USER");         //Get user name 
    char* home = getenv("HOME");        //get cwd
//printf("home = %s \n usr = %s \n", home, username);

//chdir("/home/simon");

	FILE *file = fopen(".uvshrc", "r");
	if (file == NULL){
		fprintf(stderr, "Can't find .uvshrc file\n");
		exit(1);
	}
	int i =0;
	while (fgets(line, sizeof(line), file)){
		if (line[strlen(line)-1] == '\n'){
			line[strlen(line)-1] = '\0';
			lineCount++;
		}
		strncpy(&uvshrcLines[i][0], line, strlen(line));
		i = i+1;	
	}
	fclose(file);
    for(;;) {

	printf("%s",&uvshrcLines[0][0]);

        	fgets(input, MAX_INPUT_LINE, stdin);
        	if (input[strlen(input) - 1] == '\n') {
            		input[strlen(input) - 1] = '\0';
        	}

		set(input, home, username);

        	//line_len = strlen(input); 
		if (strcmp(input, "exit") == 0) {
            		exit(0);
        	}else if (checkCd(input)==0){
			// successfully executed command

		}else if (testmul(input) > 0) {

		}else if (testPipe(input)>0){
			// if true the input would have been executed at this step

		}else if (testPipeToFile(input)>0){
			// if true input command would have been executed at the boolean eveluation phase

		}else{
			
			command(input);
		} 





    }
}
