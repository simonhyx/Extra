/*Required Headers*/

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <semaphore.h>
#include "rw.h"
#include "resource.h"

/*
 * Declarations for reader-writer shared variables -- plus concurrency-control
 * variables -- must START here.
 */

sem_t keys;

int reader;
int writerRequests;

static resource_t data;

void initialize_readers_writer() {
    /*
     * Initialize the shared structures, including those used for
     * synchronization.
     */
	sem_init(&keys,0,1);
	reader = 0;
	writerRequests;
}


void rw_read(char *value, int len) {
    printf("NOTHING IMPLEMENTED YET FOR rw_read\n");
	
	sem_wait(&keys);
	reader++;
	sem_post(&keys);	
	// issue read
	read_resource(&data,value,len);
	sem_wait(&keys);
	reader--;
	sem_post(&keys);
	
	
	
	
}


void rw_write(char *value, int len) {
    printf("NOTHING IMPLEMENTED YET FOR rw_write\n");
	writerRequest++;
	for(;;){
		sem_wait(&keys);
		if(reader == 0){
			break;
		}else{
			sem_post(&keys);
		}
	}
	
	// now writer has key. no one can enter.
	// issue write
printf("reader = %d\n", reader);
	write_resource(&data,value,len);
	sem_post(&keys);
	
	
}
